class digram{
	
}